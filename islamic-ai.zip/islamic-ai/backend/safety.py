FATWA_HINTS = ["فتویٰ", "فتوی", "جائز ہے", "حرام ہے", "طلاق", "وراثت", "fatwa", "halal", "haram", "talaq"]
DISCLAIMER = "\n\n⚠️ یہ عمومی معلومات ہیں، فتویٰ نہیں۔ ذاتی صورتِ حال کے لیے کسی مستند عالم سے رجوع کریں۔"

def needs_disclaimer(question: str) -> bool:
    q = question.lower()
    return any(h in q for h in FATWA_HINTS)
