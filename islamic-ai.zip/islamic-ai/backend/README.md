# چلانے کا طریقہ
cd backend
pip install -r requirements.txt
cp .env.example .env      # اور اپنی API key لکھیں
uvicorn main:app --reload
# ٹیسٹ: POST http://localhost:8000/chat  {"question": "صبر کے بارے میں قرآن کیا کہتا ہے؟"}
