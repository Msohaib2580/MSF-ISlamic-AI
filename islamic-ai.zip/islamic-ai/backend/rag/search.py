"""سوال سے ملتے ماخذ تلاش کرنا (semantic search)۔
data/sources.json صرف نمونہ ہے۔ اسے Tanzil.net (قرآن) اور
Sunnah.com (حدیث) کے تصدیق شدہ ڈیٹا سے بدلیں۔
فارمیٹ: [{"ref": "...", "arabic": "...", "text": "..."}]
"""
import json
from pathlib import Path
import numpy as np
from sentence_transformers import SentenceTransformer

_model = SentenceTransformer("paraphrase-multilingual-MiniLM-L12-v2")
_docs = json.loads((Path(__file__).parent.parent / "data" / "sources.json").read_text(encoding="utf-8"))
_vecs = _model.encode([d["text"] for d in _docs], normalize_embeddings=True)

def search(query: str, k: int = 4, min_score: float = 0.25):
    q = _model.encode([query], normalize_embeddings=True)[0]
    scores = _vecs @ q
    top = np.argsort(-scores)[:k]
    return [{**_docs[i], "score": float(scores[i])} for i in top if scores[i] >= min_score]
