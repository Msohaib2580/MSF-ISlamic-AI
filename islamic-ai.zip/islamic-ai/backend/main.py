import os
from dotenv import load_dotenv
from fastapi import FastAPI
from pydantic import BaseModel
import anthropic
from rag.search import search
from rag.prompt import SYSTEM, build_user_message
from safety import needs_disclaimer, DISCLAIMER

load_dotenv()
client = anthropic.Anthropic()  # ANTHROPIC_API_KEY .env سے آتی ہے
MODEL = os.getenv("CLAUDE_MODEL", "claude-sonnet-4-6")
app = FastAPI()

class Msg(BaseModel):
    role: str  # "user" یا "assistant"
    content: str

class ChatIn(BaseModel):
    question: str
    history: list[Msg] = []

@app.post("/chat")
def chat(body: ChatIn):
    sources = search(body.question)
    messages = [m.model_dump() for m in body.history[-6:]]
    messages.append({"role": "user", "content": build_user_message(body.question, sources)})
    r = client.messages.create(model=MODEL, max_tokens=800, system=SYSTEM, messages=messages)
    answer = r.content[0].text
    if needs_disclaimer(body.question):
        answer += DISCLAIMER
    return {"answer": answer, "references": [s["ref"] for s in sources]}
